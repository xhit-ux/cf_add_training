import { app, BrowserWindow, ipcMain, session } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import { fetchGroups } from './fetchGroups';

let win: BrowserWindow;

async function extractCookiesAsHeader(): Promise<string> {
  const cookies = await session.fromPartition('persist:authsession').cookies.get({});
  fs.mkdirSync('cookies', { recursive: true });
  fs.writeFileSync('cookies/cookies.json', JSON.stringify(cookies, null, 2));

  const cookieHeader = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
  console.log('\n[+] 构造出的 Cookie 请求头格式:');
  console.log(cookieHeader);

  // 执行抓取 Group 页面的 HTML
  const html = await fetchGroups(cookieHeader);
  win.loadFile(path.join(__dirname, '../public/mygroup.html'));

  // 发送给前端页面（mygroup.html）
  win.webContents.once('did-finish-load', () => {
    win.webContents.send('group-html', html);
  });

  return cookieHeader;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      webviewTag: true,
      partition: 'persist:authsession'
    }
  });

  win.loadFile(path.join(__dirname, '../public/login.html'));
}

ipcMain.handle('save-cookies', async () => {
  const cookieHeader = await extractCookiesAsHeader();
  return { status: 'done' };
});

app.whenReady().then(() => {
  createWindow();
});
